
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'ribery93',
  applicationName: 'capstone-goal-app',
  appUid: 'NxBZLYwVlYxTvV6F62',
  orgUid: 'bcd32321-4bf3-4901-8863-8427f8bd6f24',
  deploymentUid: '5bbf9e1d-f5f1-4211-b8c0-db225fabc7ce',
  serviceName: 'capstone-goal-app',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '5.5.0',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'capstone-goal-app-dev-CreateGoal', timeout: 6 };

try {
  const userHandler = require('./src/lambda/http/createGoal.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}